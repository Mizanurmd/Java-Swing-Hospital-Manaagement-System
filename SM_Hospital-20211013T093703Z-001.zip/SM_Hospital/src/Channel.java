
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author J2EE-45
 */
public class Channel extends javax.swing.JFrame {

    /**
     * Creates new form Channel
     */
    public Channel() {
        initComponents();
        Connect();
        AutoID();
        LoadDoctor();
        LoadPatient();
        channel_table();
    }
    
//    ========================================================== For Doctor Name
  
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    String chno;
    
    
    public class Doctor{
    
    String id;
    String name;
    
     public  Doctor(String id, String name){
      this.id = id;
      this.name = name;
      
  } 
     
      public String toString(){
        return name;
    }
    
}
    
//    ========================================================== For Patient Name
    
    public class Patient{
    
    String id;
    String name;
    
     public  Patient(String id, String name){
      this.id = id;
      this.name = name;
      
  } 
     
      public String toString(){
        return name;
    }
    
}
    
//  ==============================================================For Doctor Name loading
    
    public void LoadPatient(){
        try {
            pst = con.prepareStatement("select * from Patient");
            rs = pst.executeQuery();
            pName.removeAll();
            
            while(rs.next()){
                pName.addItem(new Patient(rs.getString(1),rs.getString(2)));
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Channel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
//  ==============================================================For Doctor Name loading
    
    public void LoadDoctor(){
        try {
            pst = con.prepareStatement("select * from Doctor");
            rs = pst.executeQuery();
            dName.removeAll();
            
            while(rs.next()){
                dName.addItem(new Doctor(rs.getString(1),rs.getString(2)));
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Channel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 
    
    
    
    
    
//    ==============================================================================
     public void Connect(){
        
        try {
          
           Class.forName("com.mysql.jdbc.Driver");
           con = DriverManager.getConnection( "jdbc:mysql://localhost/hospital", "root", "");
          
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Channel.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Channel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
     
     
//      ==============================================================================For Patient Serial No
     
     public void AutoID(){
        
        try {
            Statement s = con.createStatement();
            rs = s.executeQuery("select MAX(channel) from channel");
            rs.next();
            rs.getString("MAX(channel)");
            
            if (rs.getString("MAX(channel)") == null) {
                
                labch.setText("CH001");
                
            }
            else{
                
                long id = Long.parseLong(rs.getString("MAX(channel)").substring(2,rs.getString("MAX(channel)").length()));
                id++;
                 labch.setText("CH"+ String.format("%03d", id));
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Patient2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
//     =================================================================================
   
     
      public void channel_table(){
        
        try {
            pst = con.prepareStatement("select * from channel");
            
            rs = pst.executeQuery();
        ResultSetMetaData Rsm = rs.getMetaData();
        int c;
        c = Rsm.getColumnCount();
        
        DefaultTableModel df = (DefaultTableModel)jTable1.getModel();
        df.setRowCount(0);
        
        while(rs.next()){
            
            Vector v2 = new Vector();
            
            for (int i = 1; i <= c; i++) {
            v2.add(rs.getString("channel"));
            v2.add(rs.getString("dname"));
            v2.add(rs.getString("pname"));
            v2.add(rs.getString("roomno")); 
            v2.add(rs.getString("date")); 
           
            }
          
            df.addRow(v2);
        }
            
        } catch (SQLException ex) {
            Logger.getLogger(Patient2.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    
    
    
    
//    ==================================================================================
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        dName = new javax.swing.JComboBox();
        pName = new javax.swing.JComboBox();
        sRoom = new javax.swing.JSpinner();
        cDate = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        labch = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        btnCreate = new javax.swing.JButton();
        btnCanecel = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Channel No");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 146, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("Doctor Name");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 200, 146, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("Patient Name");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 260, 146, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("Room No");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 330, 146, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setText("Channel Date");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 390, 146, 48));

        dName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(dName, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 190, 310, 40));

        pName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(pName, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 250, 310, 40));

        sRoom.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(sRoom, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 320, 121, 38));
        getContentPane().add(cDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 390, 175, 48));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Channe No", "Doctor Name", "Patient Name", "Room No", "Channel Date"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 120, -1, -1));

        labch.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        labch.setText("jLabel6");
        getContentPane().add(labch, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 134, 270, 30));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 51, 51));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("CHANNEL");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 50, 250, -1));

        btnCreate.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnCreate.setText("Create");
        btnCreate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 0, 102), 3));
        btnCreate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreateActionPerformed(evt);
            }
        });
        getContentPane().add(btnCreate, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 489, 110, 50));

        btnCanecel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnCanecel.setText("Cancel");
        btnCanecel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 0, 102), 3));
        btnCanecel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCanecelActionPerformed(evt);
            }
        });
        getContentPane().add(btnCanecel, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 489, 110, 50));

        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\J2EE-45\\Documents\\NetBeansProjects\\SM_Hospital\\src\\patientAdd.jpg")); // NOI18N
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1450, 720));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCanecelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCanecelActionPerformed
        // TODO add your handling code here:
       
       
       

        try {
            pst = con.prepareStatement("delete from channel where channel = ?");

            pst.setString(1, chno);
           
            
           
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "delete is successful.");

            AutoID();
            channel_table();
            labch.setText("");
            dName.setSelectedIndex(-1);
            pName.setSelectedIndex(-1);
            sRoom.setValue(0);
            
           

        } catch (SQLException ex) {
            Logger.getLogger(Patient2.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
   
    }//GEN-LAST:event_btnCanecelActionPerformed

    private void btnCreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreateActionPerformed
        // TODO add your handling code here:
        
       String chNo = labch.getText();
       Doctor d = (Doctor)dName.getSelectedItem();
       Patient p = (Patient)pName.getSelectedItem();
       String romNo = sRoom.getValue().toString();
       SimpleDateFormat dateformate = new SimpleDateFormat("yyyy-MM-dd");
       String date = dateformate.format(cDate.getDate());
       
       

        try {
            pst = con.prepareStatement("insert into channel(channel, dname, pname, roomno, date)values(?, ?, ?, ?, ?)");

            pst.setString(1, chNo);
            pst.setString(2, d.id);
            pst.setString(3, p.id);
            pst.setString(4, romNo);
            pst.setString(5, date);
           
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Channel is successful.");

            AutoID();
           
            labch.setText("");
            dName.setSelectedIndex(-1);
            pName.setSelectedIndex(-1);
            sRoom.setValue(0);
            
             channel_table();
             btnCreate.setEnabled(true);
            
           

        } catch (SQLException ex) {
            Logger.getLogger(Patient2.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        
    }//GEN-LAST:event_btnCreateActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        
       
        DefaultTableModel d1 = (DefaultTableModel) jTable1.getModel();
        int selectIndex = jTable1.getSelectedRow();
        chno = d1.getValueAt(selectIndex, 0).toString();
        
        
       
        
    }//GEN-LAST:event_jTable1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Channel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Channel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Channel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Channel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
       java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Channel().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCanecel;
    private javax.swing.JButton btnCreate;
    private com.toedter.calendar.JDateChooser cDate;
    private javax.swing.JComboBox dName;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel labch;
    private javax.swing.JComboBox pName;
    private javax.swing.JSpinner sRoom;
    // End of variables declaration//GEN-END:variables
}
