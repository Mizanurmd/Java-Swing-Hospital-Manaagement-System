
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author J2EE-45
 */
public class Inventory extends javax.swing.JFrame {

    /**
     * Creates new form Inventory
     */
    public Inventory() {
        initComponents();
    }
    
//    =====================================================
    
    String pnoo;
    String npno;
    
    public Inventory(String pno) {
        initComponents();
        Connect();
        
//        ================================================For Prescription id
        
        this.pnoo = pno;
        
        npno = pnoo;
        
        jLabel6.setText(npno);
        
    }

//    ======================================================================For Connection
     
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    
    public void Connect(){
        
        try {
          
           Class.forName("com.mysql.jdbc.Driver");
           con = DriverManager.getConnection( "jdbc:mysql://localhost/hospital", "root", "");
          
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
//    =========================================================================Method for sales & sale_product table
    
    public void sales(){
        
        
        DateTimeFormatter daa = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        LocalDateTime now = LocalDateTime.now();
        String date = daa.format(now);
        
        
        String subtot = totalCost.getText();
        String pay = tPay.getText();
        String balance = tBalance.getText();
        
        
        
        int lastinsertid = 0;
        
//        =================================================================For sales table
        
        try {
            
            String query =("insert into sales(date,subtotal,pay,balance)values(?, ?, ?, ?)");
            pst = con.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
            
            pst.setString(1, date);
            pst.setString(2, subtot);
            pst.setString(3, pay);
            pst.setString(4, balance);
            
            
           pst.executeUpdate();
            
            rs = pst.getGeneratedKeys();
            
            if (rs.next()) {
                
                lastinsertid = rs.getInt(1);
                
                
                
            }
            
//            =====================================================For sale_product table

            int rows = jTable1.getColumnCount();
            
            String query1 = ("insert into sale_product(sales_id, prod_id, sellprice, qty, total) values(?, ?, ?, ?, ?)");
            pst = con.prepareStatement(query1);
            
            String pres_id;
            String item_id;
            String item_name;
            String price;
            String qty;
            int total;
            
            for (int i = 0; i < jTable1.getRowCount(); i++) {
                
                pres_id = (String)jTable1.getValueAt(i, 0);
                item_id = (String)jTable1.getValueAt(i, 1);
                qty = jTable1.getValueAt(i, 3).toString();
                int qty1 = Integer.parseInt(qty);
                
                price = jTable1.getValueAt(i, 4).toString();
                int price2 = Integer.parseInt(price);
                total = (int)jTable1.getValueAt(i, 5);
                
               
               
                
               
                
                
                pst.setInt(1, lastinsertid);
                pst.setString(2, item_id);
                pst.setInt(3, qty1);
                pst.setInt(4, price2);
                pst.setInt(5,total);
                
                pst.executeUpdate();
                
                
                JOptionPane.showMessageDialog(this, "Record is added!!!");
                
                
            }
            
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
    }
    
    
    
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        textCode = new javax.swing.JTextField();
        textdName = new javax.swing.JTextField();
        quanti = new javax.swing.JSpinner();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        totalCost = new javax.swing.JTextField();
        tPay = new javax.swing.JTextField();
        tBalance = new javax.swing.JTextField();
        btnAdd = new javax.swing.JButton();
        btnSalesUp = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 0));
        jLabel2.setText("Prescription ID");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 46, 160, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 0));
        jLabel3.setText("Drug Code");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 106, 160, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 0));
        jLabel4.setText("Drug Name");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 172, 160, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 0));
        jLabel5.setText("Qty");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 236, 160, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 51));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("jLabel6");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(262, 46, 173, -1));

        textCode.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        textCode.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textCodeKeyPressed(evt);
            }
        });
        jPanel1.add(textCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(262, 103, 173, -1));

        textdName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jPanel1.add(textdName, new org.netbeans.lib.awtextra.AbsoluteConstraints(262, 169, 173, -1));

        quanti.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jPanel1.add(quanti, new org.netbeans.lib.awtextra.AbsoluteConstraints(262, 236, 101, 32));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Prescription ID", "Drug Code", "Drug Name", "Qty", "Price", "Total"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(73, 304, 737, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 51));
        jLabel7.setText("TotalCost");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(504, 46, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 51));
        jLabel8.setText("Pay");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(504, 106, 84, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 51));
        jLabel9.setText("Balance");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(504, 172, 84, -1));

        totalCost.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jPanel1.add(totalCost, new org.netbeans.lib.awtextra.AbsoluteConstraints(637, 43, 173, -1));

        tPay.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jPanel1.add(tPay, new org.netbeans.lib.awtextra.AbsoluteConstraints(637, 103, 173, -1));

        tBalance.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jPanel1.add(tBalance, new org.netbeans.lib.awtextra.AbsoluteConstraints(637, 169, 173, -1));

        btnAdd.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnAdd.setForeground(new java.awt.Color(51, 51, 255));
        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });
        jPanel1.add(btnAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(504, 237, 84, -1));

        btnSalesUp.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnSalesUp.setForeground(new java.awt.Color(51, 51, 255));
        btnSalesUp.setText("SalesUpdate");
        btnSalesUp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalesUpActionPerformed(evt);
            }
        });
        jPanel1.add(btnSalesUp, new org.netbeans.lib.awtextra.AbsoluteConstraints(637, 237, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 870, 770));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Sales");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 0, 263, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void textCodeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textCodeKeyPressed
       
        
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            
            String dcode = textCode.getText();
            
            
            try {
                
                pst = con.prepareStatement("select * from item where itemid = ?");
                pst.setString(1, dcode);
                rs = pst.executeQuery();
                
                
                
                if (rs.next()== false) {
                    
                    JOptionPane.showMessageDialog(this, "Don't found drug .");
                    
                }
                else{
                    
                    String dname = rs.getString("itemname");
                    textdName.setText(dname.trim());
                    quanti.requestFocus();
                    
                    
                    
                }
                
                
                
            } catch (SQLException ex) {
                Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            
            
        }
        
        
        
        
        
    }//GEN-LAST:event_textCodeKeyPressed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
       
        
          String dcode = textCode.getText();
        
        try {
            pst = con.prepareStatement("select * from item where itemid = ?");
             pst.setString(1, dcode);
             rs = pst.executeQuery();
             
             while(rs.next()){
                 int currentqty;
                 int sellprice;
                 int qty;
                 
                 currentqty = rs.getInt("qty");
                 sellprice  = rs.getInt("sellprice");
                 
                 qty  =Integer.parseInt(quanti.getValue().toString());
                 
                 int total = sellprice*qty;
                 
                 
                 
                 
                 if (qty > currentqty) {
                     
                     JOptionPane.showMessageDialog(this, "Available item"+currentqty);
                     JOptionPane.showMessageDialog(this, "Qty is not enough");
                     
                 }else{
                     
                   DefaultTableModel DF = (DefaultTableModel)jTable1.getModel();
                   DF.addRow(new Object[]{
                       
                       jLabel6.getText(),
                       textCode.getText(),
                       textdName.getText(),
                       quanti.getValue().toString(),
                       
                       sellprice,
                       total,
                           
                      
                   
                   
                       
                   });
                   
                   
                   int sum = 0;
                     for (int i = 0; i < jTable1.getRowCount(); i++) {
                         
                         sum = sum + Integer.parseInt(jTable1.getValueAt(i, 5).toString());
                         
                     }
                  
                     totalCost.setText(Integer.toString(sum));
                   textCode.setText("");
                   textdName.setText("");
                   quanti.setValue(0);
                   textCode.requestFocus();
                   
                   
                 }
                 
                 
                 
             }
             
             
             
            
        } catch (SQLException ex) {
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }
               
        
        
        
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnSalesUpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalesUpActionPerformed
        
        
        int pay =(Integer.parseInt(tPay.getText()));
        int totcost =(Integer.parseInt(totalCost.getText()));
        
        
        int balance = pay-totcost;
        
        tBalance.setText(String.valueOf(balance));
        
         sales();
        
        
        
    }//GEN-LAST:event_btnSalesUpActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inventory().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnSalesUp;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JSpinner quanti;
    private javax.swing.JTextField tBalance;
    private javax.swing.JTextField tPay;
    private javax.swing.JTextField textCode;
    private javax.swing.JTextField textdName;
    private javax.swing.JTextField totalCost;
    // End of variables declaration//GEN-END:variables
}
